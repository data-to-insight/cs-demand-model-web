from ._configuration_loader import Config

__all__ = ["Config"]
